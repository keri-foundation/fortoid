# -*- encoding: utf-8 -*-
"""
KERI
keri.kli.commands.contacts module

"""
import argparse
import json
import sys

from hio.base import doing
from hio.help import ogler

from ...common import existingHby, Parsery
from ....kering import ValidationError, ConfigurationError
from ....app import Organizer


logger = ogler.getLogger()

parser = argparse.ArgumentParser(description='List existing contacts', 
                                 parents=[Parsery.keystore()])
parser.set_defaults(handler=lambda args: handler(args))

def handler(args):
    kwa = dict(args=args)
    return [doing.doify(list, **kwa)]


def list(tymth, tock=0.0, **opts):
    """ Command line status handler

    """
    _ = (yield tock)
    args = opts["args"]
    name = args.name
    base = args.base
    bran = args.bran

    try:
        with existingHby(name=name, base=base, bran=bran) as hby:
            org = Organizer(hby=hby)
            for c in org.list():

                aid = c['id']
                accepted = [diger.qb64 for diger in hby.db.chas.get(keys=(aid,))]
                received = [diger.qb64 for diger in hby.db.reps.get(keys=(aid,))]
                valid = set(accepted) & set(received)

                challenges = []
                for said in valid:
                    try:
                        exn = hby.db.exns.get(keys=(said,))
                    except ValidationError:
                        val = hby.db.getVal(db=hby.db.exns.sdb, key=hby.db.exns._tokey((said,)))
                        d = json.loads(bytes(val).decode("utf-8"))
                        challenges.append(dict(dt=d['dt'], words=d['a']['words']))
                    else:
                        challenges.append(dict(dt=exn.ked['dt'], words=exn.ked['a']['words']))

                c["challenges"] = challenges

                wellKnowns = []
                wkans = hby.db.wkas.get(keys=(aid,))
                for wkan in wkans:
                    wellKnowns.append(dict(url=wkan.url, dt=wkan.dt))

                c["wellKnowns"] = wellKnowns

                print(json.dumps(c, indent=2))

    except ConfigurationError as e:
        print(f"identifier prefix for {name} does not exist, incept must be run first", )
        sys.exit(-1)
