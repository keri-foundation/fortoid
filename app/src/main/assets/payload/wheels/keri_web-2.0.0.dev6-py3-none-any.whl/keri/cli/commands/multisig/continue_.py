# -*- encoding: utf-8 -*-
"""
KERI
keri.kli.commands module

"""
import argparse

from hio.base import doing
from hio.help import ogler

from ...common import Parsery, setupHby, printIdentifier

from ....app import (GroupHab, MailboxDirector,
                     Counselor, WitnessInquisitor)


logger = ogler.getLogger()

parser = argparse.ArgumentParser(description='Process any incoming events that will progress local pending multisig '
                                             'events.',
                                 parents=[Parsery.keystore()])
parser.set_defaults(handler=lambda args: handler(args) )
parser.add_argument('--alias', '-a', help='human readable alias for the local identifier prefix', required=True)


def handler(args):
    kever = ContinueDoer(name=args.name, base=args.base, bran=args.bran, alias=args.alias)
    return [kever]


class ContinueDoer(doing.DoDoer):
    """ DoDoer running the doers for recovering pending multisig events. """

    def __init__(self, name, base, bran, alias):
        self.hby = setupHby(name=name, base=base, bran=bran)
        self.alias = alias
        self.counselor = Counselor(hby=self.hby)
        self.witq = WitnessInquisitor(hby=self.hby)
        self.mbx = MailboxDirector(hby=self.hby,
                                   topics=["/receipt", "/replay", "/multisig", "/credential", "/delegate",
                                           "/challenge", "/oobi"])
        doers = [self.mbx, self.counselor, self.witq, doing.doify(self.recover)]
        super(ContinueDoer, self).__init__(doers=doers)

    def recover(self, tymth, tock=0.0, **opts):
        """ Command line status handler

        """
        self.wind(tymth)
        self.tock = tock
        _ = (yield tock)

        hab = self.hby.habByName(self.alias)
        if hab is None:
            raise ValueError(f"no AID with alias {self.alias}")

        esc = self.hby.db.gdee.get(keys=(hab.pre,))
        if not esc:
            raise ValueError(f"no escrowed events for {self.alias} ({hab.pre})")

        (number, diger) = esc[0]
        src = hab.mhab.pre if isinstance(hab, GroupHab) else hab.pre
        anchor = dict(i=hab.pre, s=number.numh, d=diger.qb64)
        self.witq.query(src=src, pre=hab.kever.delpre, anchor=anchor)

        print(f"Checking mailboxes for any events to process")
        while self.hby.db.cgms.get(keys=(hab.pre, number.qb64)) is None:
            yield 1.0

        print()
        printIdentifier(self.hby, hab.pre)

        self.remove([self.mbx, self.counselor, self.witq])
        return True
