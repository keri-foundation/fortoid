# -*- encoding: utf-8 -*-
"""
KERI
keri.kli.commands module

"""
import argparse

from hio.base import doing
from hio.help import ogler

from ...common import setupHby, Parsery

from ....kering import Vrsn_1_0, ConfigurationError
from ....app import (GroupHab, Multiplexor, MailboxDirector,
                     Poster, WitnessPublisher, Notifier,
                     multisigRpyExn)
from ....app.grouping import loadHandlers

from ....core import Parser
from ....peer import Exchanger


logger = ogler.getLogger()

parser = argparse.ArgumentParser(description='Add new endpoint role authorization.', 
                                 parents=[Parsery.keystore()])
parser.set_defaults(handler=lambda args: add_end(args))
parser.add_argument('--alias', '-a', help='human readable alias for the new identifier prefix', required=True)
parser.add_argument("--role", "-r", help="KERI enpoint authorization role.",
                    required=True)
parser.add_argument("--eid", "-e", help="qualified base64 of AID to authorize with new role for the AID identified "
                                        "by alias",
                    required=True)
parser.add_argument("--time", help="timestamp for the end auth", required=False, default=None)


def add_end(args):
    """ Command line tool for adding endpoint role authorizations

    """
    ld = RoleDoer(name=args.name,
                  base=args.base,
                  alias=args.alias,
                  bran=args.bran,
                  role=args.role,
                  eid=args.eid,
                  timestamp=args.time)
    return [ld]


class RoleDoer(doing.DoDoer):

    def __init__(self, name, base, alias, bran, role, eid, timestamp=None):
        self.role = role
        self.eid = eid
        self.timestamp = timestamp

        self.hby = setupHby(name=name, base=base, bran=bran)
        self.hab = self.hby.habByName(alias)
        self.witpub = WitnessPublisher(hby=self.hby)
        self.postman = Poster(hby=self.hby)
        notifier = Notifier(self.hby)
        mux = Multiplexor(self.hby, notifier=notifier)
        exc = Exchanger(hby=self.hby, handlers=[])
        loadHandlers(exc, mux)

        mbx = MailboxDirector(hby=self.hby, topics=["/receipt", "/multisig", "/replay"], exc=exc)

        if self.hab is None:
            raise ConfigurationError(f"unknown alias={alias}")

        self.toRemove = [self.witpub, self.postman, mbx]

        super(RoleDoer, self).__init__(doers=self.toRemove + [doing.doify(self.roleDo)])

    def roleDo(self, tymth, tock=0.0, **kwa):
        """ Export any end reply messages previous saved for the provided AID

        Parameters:
            tymth (function): injected function wrapper closure returned by .tymen() of
                Tymist instance. Calling tymth() returns associated Tymist .tyme.
            tock (float): injected initial tock value

        Returns:  doifiable Doist compatible generator method

        """
        # enter context
        self.wind(tymth)
        self.tock = tock
        _ = (yield self.tock)

        data = dict(cid=self.hab.pre, role=self.role, eid=self.eid)

        route = "/end/role/add"
        msg = self.hab.reply(route=route, data=data, stamp=self.timestamp)

        Parser(version=Vrsn_1_0).parse(ims=bytes(msg), kvy=self.hab.kvy, rvy=self.hab.rvy)

        if isinstance(self.hab, GroupHab):
            smids = self.hab.db.signingMembers(pre=self.hab.pre)
            smids.remove(self.hab.mhab.pre)

            for recp in smids:  # this goes to other participants only as a signaling mechanism
                exn, atc = multisigRpyExn(ghab=self.hab, rpy=msg)
                self.postman.send(src=self.hab.mhab.pre,
                                  dest=recp,
                                  topic="multisig",
                                  serder=exn,
                                  attachment=atc)

        while not self.hab.loadEndRole(cid=self.hab.pre, role=self.role, eid=self.eid):
            yield self.tock

        self.witpub.msgs.append(dict(pre=self.hab.pre, msg=bytes(msg)))

        while not self.witpub.cues:
            yield self.tock

        print(f"End role authorization added for role {self.role}")

        self.remove(self.toRemove)
        return
