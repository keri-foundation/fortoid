# -*- encoding: utf-8 -*-
"""
KERI
keri.db Package
"""

import importlib


_MODULES = {
    "basing": ".basing",
    "dbing": ".dbing",
    "escrowing": ".escrowing",
    "koming": ".koming",
    "subing": ".subing",
    "webdbing": ".webdbing",
}

_EXPORTS = {
    "Baser": (".basing", "Baser"),
    "BaserBase": (".basebasing", "BaserBase"),
    "BaserDoer": (".basing", "BaserDoer"),
    "openDB": (".basing", "openDB"),
    "reopenDB": (".basing", "reopenDB"),
    "statedict": (".basebasing", "statedict"),
    "LMDBer": (".dbing", "LMDBer"),
    "clearDatabaserDir": (".dbing", "clearDatabaserDir"),
    "openLMDB": (".dbing", "openLMDB"),
    "onKey": (".dbing", "onKey"),
    "snKey": (".dbing", "snKey"),
    "fnKey": (".dbing", "fnKey"),
    "dgKey": (".dbing", "dgKey"),
    "dtKey": (".dbing", "dtKey"),
    "splitKey": (".dbing", "splitKey"),
    "splitOnKey": (".dbing", "splitOnKey"),
    "splitKeyDT": (".dbing", "splitKeyDT"),
    "fetchTsgs": (".dbing", "fetchTsgs"),
    "suffix": (".dbing", "suffix"),
    "unsuffix": (".dbing", "unsuffix"),
    "splitKeyFN": (".dbing", "splitKeyFN"),
    "SuffixSize": (".dbing", "SuffixSize"),
    "splitSnKey": (".dbing", "splitSnKey"),
    "MaxSuffix": (".dbing", "MaxSuffix"),
    "WebDBer": (".webdbing", "WebDBer"),
    "Broker": (".escrowing", "Broker"),
    "KomerBase": (".koming", "KomerBase"),
    "Komer": (".koming", "Komer"),
    "IoSetKomer": (".koming", "IoSetKomer"),
    "DupKomer": (".koming", "DupKomer"),
    "SuberBase": (".subing", "SuberBase"),
    "Suber": (".subing", "Suber"),
    "OnSuberBase": (".subing", "OnSuberBase"),
    "OnSuber": (".subing", "OnSuber"),
    "B64SuberBase": (".subing", "B64SuberBase"),
    "B64Suber": (".subing", "B64Suber"),
    "CesrSuberBase": (".subing", "CesrSuberBase"),
    "CesrSuber": (".subing", "CesrSuber"),
    "CesrOnSuber": (".subing", "CesrOnSuber"),
    "CatCesrSuberBase": (".subing", "CatCesrSuberBase"),
    "CatCesrSuber": (".subing", "CatCesrSuber"),
    "IoSetSuber": (".subing", "IoSetSuber"),
    "B64IoSetSuber": (".subing", "B64IoSetSuber"),
    "CesrIoSetSuber": (".subing", "CesrIoSetSuber"),
    "CatCesrIoSetSuber": (".subing", "CatCesrIoSetSuber"),
    "SignerSuber": (".subing", "SignerSuber"),
    "CryptSignerSuber": (".subing", "CryptSignerSuber"),
    "SerderSuberBase": (".subing", "SerderSuberBase"),
    "SerderSuber": (".subing", "SerderSuber"),
    "SerderIoSetSuber": (".subing", "SerderIoSetSuber"),
    "SchemerSuber": (".subing", "SchemerSuber"),
    "DupSuber": (".subing", "DupSuber"),
    "CesrDupSuber": (".subing", "CesrDupSuber"),
    "CatCesrDupSuber": (".subing", "CatCesrDupSuber"),
    "IoDupSuber": (".subing", "IoDupSuber"),
    "B64IoDupSuber": (".subing", "B64IoDupSuber"),
    "OnIoDupSuber": (".subing", "OnIoDupSuber"),
    "B64OnIoDupSuber": (".subing", "B64OnIoDupSuber"),
    "OnIoSetSuber": (".subing", "OnIoSetSuber"),
    "B64OnIoSetSuber": (".subing", "B64OnIoSetSuber"),
}

__all__ = [*_MODULES, *_EXPORTS]


def __getattr__(name):
    if name in _MODULES:
        module = importlib.import_module(_MODULES[name], __name__)
        globals()[name] = module
        return module

    if name in _EXPORTS:
        module_name, export_name = _EXPORTS[name]
        module = importlib.import_module(module_name, __name__)
        value = getattr(module, export_name)
        globals()[name] = value
        return value

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__():
    return sorted(set(globals()) | set(__all__))
