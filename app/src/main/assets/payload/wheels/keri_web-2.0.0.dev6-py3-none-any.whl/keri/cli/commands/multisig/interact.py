# -*- encoding: utf-8 -*-
"""
keri.kli.commands.multisig module

"""

import argparse
from ordered_set import OrderedSet as oset

from hio.base import doing
from hio.help import ogler

from ...common import Parsery, config, setupHby, printIdentifier

from ....kering import ConfigurationError
from ....app import (Notifier, Multiplexor, Counselor,
                     MailboxDirector, HaberyDoer, Poster,
                     multisigInteractExn)
from ....app.grouping import loadHandlers

from ....core import Prefixer, Number, Diger, SerderKERI
from ....peer import Exchanger


logger = ogler.getLogger()

parser = argparse.ArgumentParser(description='Begin or join a rotation of a group identifier', 
                                 parents=[Parsery.keystore()])
parser.set_defaults(handler=lambda args: interactGroupIdentifier(args))
parser.add_argument('--alias', '-a', help='human readable alias for the local identifier prefix', required=True)
parser.add_argument('--data', '-d', help='Anchor data, \'@\' allowed', default=[], action="store", required=True)
parser.add_argument("--aids", "-g", help="List of other participant qb64 identifiers to include in interaction event",
                    action="append", required=False, default=None)


def interactGroupIdentifier(args):
    """
    Performs an interaction event on the group identifier specified as an argument.  The identifier prefix of the
    environment represented by the name parameter must be a member of the group identifier.  This command will
    perform an interaction of the local identifier if the sequence number of the local identifier is the same as the
    group identifier sequence number.  It will wait for all other members of the group to achieve the same sequence
    number (group + 1) and then publish the signed interaction event for the group identifier to all witnesses and
    wait for receipts.

    Parameters:
        args (parseargs):  command line parameters

    """

    data = config.parseData(args.data) if args.data is not None else None
    ixnDoer = GroupMultisigInteract(name=args.name, alias=args.alias, aids=args.aids, base=args.base, bran=args.bran,
                                    data=data)

    doers = [ixnDoer]
    return doers


class GroupMultisigInteract(doing.DoDoer):
    """
    Command line DoDoer to launch the needed coroutines to run launch Multisig interaction.
       This DoDoer will remove the multisig coroutine and exit when it receives a message
       that the multisig coroutine has successfully completed a cooperative rotation.

       ToDo: NRR
       Add .rmids and .smids

    """

    def __init__(self, name, alias, aids, base, bran, data):
        self.base = base
        self.bran = bran
        self.alias = alias
        self.aids = aids
        self.data = data

        self.hby = setupHby(name=name, base=base, bran=bran)
        self.hbyDoer = HaberyDoer(habery=self.hby)  # setup doer
        self.postman = Poster(hby=self.hby)

        notifier = Notifier(self.hby)
        mux = Multiplexor(self.hby, notifier=notifier)
        exc = Exchanger(hby=self.hby, handlers=[])
        loadHandlers(exc, mux)

        mbd = MailboxDirector(hby=self.hby, topics=['/receipt', '/multisig'], exc=exc)
        self.counselor = Counselor(hby=self.hby)

        doers = [self.hbyDoer, self.postman, mbd, self.counselor]
        self.toRemove = list(doers)

        doers.extend([doing.doify(self.interactDo)])

        super(GroupMultisigInteract, self).__init__(doers=doers)

    def interactDo(self, tymth, tock=0.0, **kwa):
        """ Create or participate in an interaction event for a distributed multisig identifier

        Parameters:
            tymth (function): injected function wrapper closure returned by .tymen() of
                Tymist instance. Calling tymth() returns associated Tymist .tyme.
            tock (float): injected initial tock value

        """
        # enter context
        self.wind(tymth)
        self.tock = tock
        _ = (yield self.tock)

        ghab = self.hby.habByName(name=self.alias)
        if ghab is None:
            raise ConfigurationError(f"invalid alias {self.alias} specified for database {self.hby.name}")

        aids = self.aids if self.aids is not None else ghab.smids

        ixn = ghab.interact(data=self.data)
        serder = SerderKERI(raw=ixn)

        exn, ims = multisigInteractExn(ghab=ghab, aids=aids, ixn=ixn)
        others = list(oset(ghab.smids + (ghab.rmids or [])))
        others.remove(ghab.mhab.pre)

        for recpt in others:  # send notification to other participants as a signalling mechanism
            self.postman.send(src=ghab.mhab.pre, dest=recpt, topic="multisig", serder=exn, attachment=ims)

        prefixer = Prefixer(qb64=ghab.pre)
        number = Number(sn=serder.sn)
        diger = Diger(qb64b=serder.saidb)
        self.counselor.start(prefixer=prefixer, number=number, diger=diger, ghab=ghab)

        while True:
            saider = self.hby.db.cgms.get(keys=(prefixer.qb64, number.qb64))
            if saider is not None:
                break

            yield self.tock

        print()
        printIdentifier(self.hby, ghab.pre)
        self.remove(self.toRemove)
