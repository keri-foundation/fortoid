# -*- encoding: utf-8 -*-
"""
hio package
"""

__version__ = '0.7.20'  # also change in setup.py

from .hioing import (Mixin, HioError, SizeError, ValidationError, VersionError,
                     HierError, MultiError, MemoerError, MemoerVerifyError)
