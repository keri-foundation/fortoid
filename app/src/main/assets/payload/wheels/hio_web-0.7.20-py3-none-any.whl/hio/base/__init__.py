# -*- encoding: utf-8 -*-
"""
hio.base Package
"""

import importlib

from .tyming import Tymist, Tymee, Tymer
from .doing import Doist, doize, doify, Doer, DoDoer
from .filing import openFiler, Filer, FilerDoer
from .multidoing import Bosser, Crewer, TagDex


_DURING_EXPORTS = {
    "Duror",
    "openDuror",
    "SuberBase",
    "Suber",
    "IoSuber",
    "IoSetSuber",
    "DomSuberBase",
    "DomSuber",
    "DomIoSuber",
    "DomIoSetSuber",
    "Subery",
}

__all__ = [
    "Tymist",
    "Tymee",
    "Tymer",
    "Doist",
    "doize",
    "doify",
    "Doer",
    "DoDoer",
    "openFiler",
    "Filer",
    "FilerDoer",
    "Bosser",
    "Crewer",
    "TagDex",
    "during",
    *_DURING_EXPORTS,
]


def __getattr__(name):
    if name == "during":
        module = importlib.import_module(".during", __name__)
        globals()[name] = module
        return module

    if name in _DURING_EXPORTS:
        module = importlib.import_module(".during", __name__)
        value = getattr(module, name)
        globals()[name] = value
        return value

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__():
    return sorted(set(globals()) | set(__all__))
