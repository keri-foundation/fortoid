"""
Compatibility wrapper exposing pychloride under the pysodium import name.
"""

from pychloride import *  # noqa: F401,F403
